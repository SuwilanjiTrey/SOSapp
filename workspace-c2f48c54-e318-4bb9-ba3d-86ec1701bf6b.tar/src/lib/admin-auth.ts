'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import * as React from 'react'

export function useAdminAuth() {
  const router = useRouter()

  useEffect(() => {
    const isAuthenticated = localStorage.getItem('isAdminAuthenticated') === 'true'
    
    if (!isAuthenticated) {
      router.push('/admin/login')
    }
  }, [router])
}

export function requireAdminAuth(Component: React.ComponentType<any>) {
  return function AdminAuthWrapper(props: any) {
    useAdminAuth()
    return React.createElement(Component, props)
  }
}