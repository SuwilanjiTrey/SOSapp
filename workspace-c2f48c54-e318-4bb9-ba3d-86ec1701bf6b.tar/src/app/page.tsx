'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Shield, Users, AlertTriangle, BarChart3, Settings } from 'lucide-react'

export default function Home() {
  const router = useRouter()

  const features = [
    {
      icon: AlertTriangle,
      title: 'SOS Event Monitoring',
      description: 'Real-time monitoring and management of emergency alerts'
    },
    {
      icon: Users,
      title: 'User Management',
      description: 'Manage user accounts, permissions, and access controls'
    },
    {
      icon: BarChart3,
      title: 'Analytics Dashboard',
      description: 'Comprehensive analytics and insights into system performance'
    },
    {
      icon: Settings,
      title: 'System Configuration',
      description: 'Configure email, SMS, and notification settings'
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-white">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <div className="flex justify-center mb-6">
            <div className="relative w-24 h-24 bg-red-600 rounded-full flex items-center justify-center">
              <Shield className="w-12 h-12 text-white" />
            </div>
          </div>
          <h1 className="text-5xl font-bold text-gray-900 mb-4">SafeCircle Admin</h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Comprehensive admin interface for monitoring and managing the SafeCircle emergency response system
          </p>
          <Button 
            size="lg" 
            className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 text-lg"
            onClick={() => router.push('/admin/login')}
          >
            Access Admin Panel
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {features.map((feature, index) => {
            const Icon = feature.icon
            return (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="mx-auto w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-red-600" />
                  </div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>{feature.description}</CardDescription>
                </CardContent>
              </Card>
            )
          })}
        </div>

        <div className="text-center">
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle>Demo Credentials</CardTitle>
              <CardDescription>Use these credentials to access the admin panel</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <p><strong>Email:</strong> admin@safecircle.app</p>
                <p><strong>Password:</strong> admin123</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}