'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  Search,
  Filter,
  MapPin,
  Phone,
  Mail,
  Calendar,
  User
} from 'lucide-react'

interface SOSRecord {
  id: string
  userId: string
  title?: string
  message?: string
  createdAt: string
  location: { lat: number; lng: number; accuracy?: number }
  status: 'queued' | 'sent' | 'acknowledged' | 'resolved'
  delivery: { emailSent: boolean; pushSent: boolean; smsSent: boolean }
  acks: Array<{ uid?: string; name?: string; timestamp: string }>
  userName?: string
  userEmail?: string
}

export default function SOSEvents() {
  const [sosRecords, setSosRecords] = useState<SOSRecord[]>([])
  const [filteredRecords, setFilteredRecords] = useState<SOSRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')
  const [dateFilter, setDateFilter] = useState<string>('all')

  useEffect(() => {
    // Mock data - in production, this would fetch from Firestore
    const mockSOSRecords: SOSRecord[] = [
      {
        id: '1',
        userId: 'user1',
        userName: 'Alice Johnson',
        userEmail: 'alice@example.com',
        title: 'Emergency Help Needed',
        message: 'I need immediate assistance at the corner of 5th and Main',
        createdAt: '2024-01-15T10:30:00Z',
        location: { lat: 40.7128, lng: -74.0060, accuracy: 10 },
        status: 'acknowledged',
        delivery: { emailSent: true, pushSent: true, smsSent: false },
        acks: [
          { name: 'John Doe', timestamp: '2024-01-15T10:32:00Z' },
          { name: 'Jane Smith', timestamp: '2024-01-15T10:35:00Z' }
        ]
      },
      {
        id: '2',
        userId: 'user2',
        userName: 'Bob Smith',
        userEmail: 'bob@example.com',
        title: 'Help Request',
        message: 'Feeling unsafe walking home',
        createdAt: '2024-01-15T09:15:00Z',
        location: { lat: 34.0522, lng: -118.2437, accuracy: 15 },
        status: 'resolved',
        delivery: { emailSent: true, pushSent: true, smsSent: false },
        acks: [
          { name: 'Mike Johnson', timestamp: '2024-01-15T09:20:00Z' }
        ]
      },
      {
        id: '3',
        userId: 'user3',
        userName: 'Carol Williams',
        userEmail: 'carol@example.com',
        title: 'Urgent SOS',
        message: 'Need help now - someone following me',
        createdAt: '2024-01-15T11:45:00Z',
        location: { lat: 51.5074, lng: -0.1278, accuracy: 8 },
        status: 'sent',
        delivery: { emailSent: true, pushSent: true, smsSent: false },
        acks: []
      },
      {
        id: '4',
        userId: 'user4',
        userName: 'David Brown',
        userEmail: 'david@example.com',
        title: 'Medical Emergency',
        message: 'Chest pain, need ambulance',
        createdAt: '2024-01-14T15:20:00Z',
        location: { lat: 35.6762, lng: 139.6503, accuracy: 5 },
        status: 'resolved',
        delivery: { emailSent: true, pushSent: true, smsSent: true },
        acks: [
          { name: 'Sarah Wilson', timestamp: '2024-01-14T15:25:00Z' },
          { name: 'Tom Davis', timestamp: '2024-01-14T15:28:00Z' }
        ]
      },
      {
        id: '5',
        userId: 'user5',
        userName: 'Emma Davis',
        userEmail: 'emma@example.com',
        title: 'Car Accident',
        message: 'Hit and run on highway',
        createdAt: '2024-01-14T08:30:00Z',
        location: { lat: 48.8566, lng: 2.3522, accuracy: 12 },
        status: 'queued',
        delivery: { emailSent: false, pushSent: false, smsSent: false },
        acks: []
      }
    ]

    setSosRecords(mockSOSRecords)
    setFilteredRecords(mockSOSRecords)
    setLoading(false)
  }, [])

  useEffect(() => {
    let filtered = sosRecords

    // Apply status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter(record => record.status === statusFilter)
    }

    // Apply date filter
    const now = new Date()
    if (dateFilter === 'today') {
      filtered = filtered.filter(record => 
        new Date(record.createdAt).toDateString() === now.toDateString()
      )
    } else if (dateFilter === 'week') {
      const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
      filtered = filtered.filter(record => 
        new Date(record.createdAt) >= weekAgo
      )
    } else if (dateFilter === 'month') {
      const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
      filtered = filtered.filter(record => 
        new Date(record.createdAt) >= monthAgo
      )
    }

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(record =>
        (record.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        record.message?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        record.userName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        record.userEmail?.toLowerCase().includes(searchTerm.toLowerCase()))
      )
    }

    setFilteredRecords(filtered)
  }, [sosRecords, searchTerm, statusFilter, dateFilter])

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'resolved': return 'bg-green-100 text-green-800'
      case 'acknowledged': return 'bg-blue-100 text-blue-800'
      case 'sent': return 'bg-yellow-100 text-yellow-800'
      case 'queued': return 'bg-gray-100 text-gray-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'resolved': return <CheckCircle className="h-4 w-4" />
      case 'acknowledged': return <Mail className="h-4 w-4" />
      case 'sent': return <Clock className="h-4 w-4" />
      case 'queued': return <AlertTriangle className="h-4 w-4" />
      default: return <AlertTriangle className="h-4 w-4" />
    }
  }

  const handleResolveSOS = (sosId: string) => {
    setSosRecords(prev => prev.map(record => 
      record.id === sosId 
        ? { ...record, status: 'resolved' as const }
        : record
    ))
  }

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">SOS Events</h1>
        <p className="text-gray-600">Monitor and manage all emergency alerts</p>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="search">Search</Label>
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="search"
                  placeholder="Search by title, message, user..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="queued">Queued</SelectItem>
                  <SelectItem value="sent">Sent</SelectItem>
                  <SelectItem value="acknowledged">Acknowledged</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="date">Date Range</Label>
              <Select value={dateFilter} onValueChange={setDateFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Select date range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Time</SelectItem>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="week">Last 7 Days</SelectItem>
                  <SelectItem value="month">Last 30 Days</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* SOS Events List */}
      <Card>
        <CardHeader>
          <CardTitle>SOS Events ({filteredRecords.length})</CardTitle>
          <CardDescription>
            Showing {filteredRecords.length} of {sosRecords.length} total events
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredRecords.map((record) => (
              <div key={record.id} className="border rounded-lg p-4 hover:bg-gray-50">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    {getStatusIcon(record.status)}
                    <Badge className={getStatusColor(record.status)}>
                      {record.status}
                    </Badge>
                    <span className="text-sm text-gray-500">
                      {new Date(record.createdAt).toLocaleString()}
                    </span>
                  </div>
                  {record.status !== 'resolved' && (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleResolveSOS(record.id)}
                    >
                      Mark Resolved
                    </Button>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium text-lg mb-1">{record.title || 'SOS Alert'}</h4>
                    <p className="text-gray-600 mb-2">{record.message}</p>
                    
                    <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                      <User className="h-4 w-4" />
                      <span>{record.userName}</span>
                      <span className="text-gray-400">•</span>
                      <span>{record.userEmail}</span>
                    </div>

                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <div className="flex items-center gap-1">
                        <Mail className="h-4 w-4" />
                        <span>{record.acks.length} acknowledgments</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        <span>{new Date(record.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <MapPin className="h-4 w-4 text-gray-500" />
                        <span className="font-medium">Location:</span>
                        <span className="text-gray-600">
                          {record.location.lat.toFixed(4)}, {record.location.lng.toFixed(4)}
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm">
                        <span className="font-medium">Delivery:</span>
                        <div className="flex gap-2">
                          {record.delivery.emailSent && (
                            <Badge variant="secondary" className="text-xs">Email</Badge>
                          )}
                          {record.delivery.pushSent && (
                            <Badge variant="secondary" className="text-xs">Push</Badge>
                          )}
                          {record.delivery.smsSent && (
                            <Badge variant="secondary" className="text-xs">SMS</Badge>
                          )}
                        </div>
                      </div>

                      {record.acks.length > 0 && (
                        <div className="space-y-1">
                          <span className="font-medium text-sm">Acknowledged by:</span>
                          <div className="flex flex-wrap gap-1">
                            {record.acks.map((ack, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {ack.name}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {filteredRecords.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                No SOS events found matching your filters.
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}