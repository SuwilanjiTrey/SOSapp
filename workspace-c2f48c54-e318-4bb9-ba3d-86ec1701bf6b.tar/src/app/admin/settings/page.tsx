'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Settings, 
  Mail, 
  Phone, 
  Bell, 
  Shield, 
  Database,
  Save,
  RefreshCw,
  AlertTriangle,
  CheckCircle
} from 'lucide-react'

interface SystemSettings {
  email: {
    enabled: boolean
    provider: 'emailjs' | 'sendgrid' | 'ses'
    apiKey: string
    fromEmail: string
    templateId: string
  }
  sms: {
    enabled: boolean
    provider: 'twilio' | 'africastalking'
    apiKey: string
    fromNumber: string
    costPerMessage: number
  }
  notifications: {
    pushEnabled: boolean
    emailEnabled: boolean
    smsEnabled: boolean
    maxRetries: number
    retryInterval: number
  }
  security: {
    rateLimitPerMinute: number
    rateLimitPerDay: number
    sessionTimeout: number
    requirePhoneVerification: boolean
  }
  dataRetention: {
    sosRetentionDays: number
    userRetentionDays: number
    autoArchive: boolean
  }
}

export default function SystemSettings() {
  const [settings, setSettings] = useState<SystemSettings | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [testStatus, setTestStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle')

  useEffect(() => {
    // Mock settings - in production, this would fetch from Firestore
    const mockSettings: SystemSettings = {
      email: {
        enabled: true,
        provider: 'emailjs',
        apiKey: '••••••••••••••••',
        fromEmail: 'noreply@safecircle.app',
        templateId: 'sos-template'
      },
      sms: {
        enabled: false,
        provider: 'twilio',
        apiKey: '••••••••••••••••',
        fromNumber: '+1234567890',
        costPerMessage: 0.05
      },
      notifications: {
        pushEnabled: true,
        emailEnabled: true,
        smsEnabled: false,
        maxRetries: 3,
        retryInterval: 300
      },
      security: {
        rateLimitPerMinute: 1,
        rateLimitPerDay: 10,
        sessionTimeout: 3600,
        requirePhoneVerification: false
      },
      dataRetention: {
        sosRetentionDays: 90,
        userRetentionDays: 365,
        autoArchive: true
      }
    }

    setSettings(mockSettings)
    setLoading(false)
  }, [])

  const handleSave = async () => {
    if (!settings) return
    
    setSaving(true)
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      // In production, this would save to Firestore
      console.log('Settings saved:', settings)
    } catch (error) {
      console.error('Failed to save settings:', error)
    } finally {
      setSaving(false)
    }
  }

  const handleTestEmail = async () => {
    setTestStatus('testing')
    try {
      // Simulate email test
      await new Promise(resolve => setTimeout(resolve, 2000))
      setTestStatus('success')
      setTimeout(() => setTestStatus('idle'), 3000)
    } catch (error) {
      setTestStatus('error')
      setTimeout(() => setTestStatus('idle'), 3000)
    }
  }

  const updateSettings = (section: keyof SystemSettings, field: string, value: any) => {
    if (!settings) return
    setSettings(prev => ({
      ...prev!,
      [section]: {
        ...prev![section],
        [field]: value
      }
    }))
  }

  if (loading || !settings) {
    return <div className="flex items-center justify-center h-64">Loading settings...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">System Settings</h1>
          <p className="text-gray-600">Configure SafeCircle system parameters and integrations</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => window.location.reload()}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Reset
          </Button>
          <Button onClick={handleSave} disabled={saving}>
            <Save className="h-4 w-4 mr-2" />
            {saving ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="email" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="email">Email</TabsTrigger>
          <TabsTrigger value="sms">SMS</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="data">Data</TabsTrigger>
        </TabsList>

        <TabsContent value="email">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="h-5 w-5" />
                Email Configuration
              </CardTitle>
              <CardDescription>
                Configure email service provider and templates for SOS notifications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Enable Email Notifications</Label>
                  <p className="text-sm text-muted-foreground">
                    Send email alerts when SOS is triggered
                  </p>
                </div>
                <Switch
                  checked={settings.email.enabled}
                  onCheckedChange={(checked) => updateSettings('email', 'enabled', checked)}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="email-provider">Email Provider</Label>
                  <Select 
                    value={settings.email.provider} 
                    onValueChange={(value) => updateSettings('email', 'provider', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="emailjs">EmailJS</SelectItem>
                      <SelectItem value="sendgrid">SendGrid</SelectItem>
                      <SelectItem value="ses">Amazon SES</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="from-email">From Email</Label>
                  <Input
                    id="from-email"
                    value={settings.email.fromEmail}
                    onChange={(e) => updateSettings('email', 'fromEmail', e.target.value)}
                    placeholder="noreply@safecircle.app"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="api-key">API Key</Label>
                  <Input
                    id="api-key"
                    type="password"
                    value={settings.email.apiKey}
                    onChange={(e) => updateSettings('email', 'apiKey', e.target.value)}
                    placeholder="Enter your API key"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="template-id">Template ID</Label>
                  <Input
                    id="template-id"
                    value={settings.email.templateId}
                    onChange={(e) => updateSettings('email', 'templateId', e.target.value)}
                    placeholder="sos-template"
                  />
                </div>
              </div>

              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  onClick={handleTestEmail}
                  disabled={testStatus === 'testing' || !settings.email.enabled}
                >
                  {testStatus === 'testing' ? 'Testing...' : 'Test Email'}
                </Button>
                {testStatus === 'success' && (
                  <Badge className="bg-green-100 text-green-800">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Test successful
                  </Badge>
                )}
                {testStatus === 'error' && (
                  <Badge className="bg-red-100 text-red-800">
                    <AlertTriangle className="h-3 w-3 mr-1" />
                    Test failed
                  </Badge>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sms">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Phone className="h-5 w-5" />
                SMS Configuration
              </CardTitle>
              <CardDescription>
                Configure SMS service provider for fallback notifications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Enable SMS Notifications</Label>
                  <p className="text-sm text-muted-foreground">
                    Send SMS alerts when email/push fails (additional costs apply)
                  </p>
                </div>
                <Switch
                  checked={settings.sms.enabled}
                  onCheckedChange={(checked) => updateSettings('sms', 'enabled', checked)}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="sms-provider">SMS Provider</Label>
                  <Select 
                    value={settings.sms.provider} 
                    onValueChange={(value) => updateSettings('sms', 'provider', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="twilio">Twilio</SelectItem>
                      <SelectItem value="africastalking">Africa's Talking</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="from-number">From Number</Label>
                  <Input
                    id="from-number"
                    value={settings.sms.fromNumber}
                    onChange={(e) => updateSettings('sms', 'fromNumber', e.target.value)}
                    placeholder="+1234567890"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sms-api-key">API Key</Label>
                  <Input
                    id="sms-api-key"
                    type="password"
                    value={settings.sms.apiKey}
                    onChange={(e) => updateSettings('sms', 'apiKey', e.target.value)}
                    placeholder="Enter your API key"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cost-per-message">Cost per Message ($)</Label>
                  <Input
                    id="cost-per-message"
                    type="number"
                    step="0.01"
                    value={settings.sms.costPerMessage}
                    onChange={(e) => updateSettings('sms', 'costPerMessage', parseFloat(e.target.value))}
                  />
                </div>
              </div>

              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <div className="flex items-center gap-2 text-yellow-800">
                  <AlertTriangle className="h-4 w-4" />
                  <span className="font-medium">Cost Warning</span>
                </div>
                <p className="text-sm text-yellow-700 mt-1">
                  SMS notifications incur additional costs. Monitor usage carefully and set appropriate limits.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Notification Settings
              </CardTitle>
              <CardDescription>
                Configure notification delivery methods and retry policies
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Push Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Send push notifications to mobile devices
                    </p>
                  </div>
                  <Switch
                    checked={settings.notifications.pushEnabled}
                    onCheckedChange={(checked) => updateSettings('notifications', 'pushEnabled', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Email Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Send email notifications to circle members
                    </p>
                  </div>
                  <Switch
                    checked={settings.notifications.emailEnabled}
                    onCheckedChange={(checked) => updateSettings('notifications', 'emailEnabled', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>SMS Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Send SMS as fallback for critical alerts
                    </p>
                  </div>
                  <Switch
                    checked={settings.notifications.smsEnabled}
                    onCheckedChange={(checked) => updateSettings('notifications', 'smsEnabled', checked)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="max-retries">Maximum Retries</Label>
                  <Input
                    id="max-retries"
                    type="number"
                    value={settings.notifications.maxRetries}
                    onChange={(e) => updateSettings('notifications', 'maxRetries', parseInt(e.target.value))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="retry-interval">Retry Interval (seconds)</Label>
                  <Input
                    id="retry-interval"
                    type="number"
                    value={settings.notifications.retryInterval}
                    onChange={(e) => updateSettings('notifications', 'retryInterval', parseInt(e.target.value))}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Security Settings
              </CardTitle>
              <CardDescription>
                Configure rate limits and security policies
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="rate-limit-minute">Rate Limit (per minute)</Label>
                  <Input
                    id="rate-limit-minute"
                    type="number"
                    value={settings.security.rateLimitPerMinute}
                    onChange={(e) => updateSettings('security', 'rateLimitPerMinute', parseInt(e.target.value))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="rate-limit-day">Rate Limit (per day)</Label>
                  <Input
                    id="rate-limit-day"
                    type="number"
                    value={settings.security.rateLimitPerDay}
                    onChange={(e) => updateSettings('security', 'rateLimitPerDay', parseInt(e.target.value))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="session-timeout">Session Timeout (seconds)</Label>
                  <Input
                    id="session-timeout"
                    type="number"
                    value={settings.security.sessionTimeout}
                    onChange={(e) => updateSettings('security', 'sessionTimeout', parseInt(e.target.value))}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Require Phone Verification</Label>
                  <p className="text-sm text-muted-foreground">
                    Users must verify phone number before sending SOS
                  </p>
                </div>
                <Switch
                  checked={settings.security.requirePhoneVerification}
                  onCheckedChange={(checked) => updateSettings('security', 'requirePhoneVerification', checked)}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="data">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Data Retention
              </CardTitle>
              <CardDescription>
                Configure data retention policies and automatic archiving
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="sos-retention">SOS Records Retention (days)</Label>
                  <Input
                    id="sos-retention"
                    type="number"
                    value={settings.dataRetention.sosRetentionDays}
                    onChange={(e) => updateSettings('dataRetention', 'sosRetentionDays', parseInt(e.target.value))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="user-retention">User Data Retention (days)</Label>
                  <Input
                    id="user-retention"
                    type="number"
                    value={settings.dataRetention.userRetentionDays}
                    onChange={(e) => updateSettings('dataRetention', 'userRetentionDays', parseInt(e.target.value))}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Auto Archive Old Records</Label>
                  <p className="text-sm text-muted-foreground">
                    Automatically archive records older than retention period
                  </p>
                </div>
                <Switch
                  checked={settings.dataRetention.autoArchive}
                  onCheckedChange={(checked) => updateSettings('dataRetention', 'autoArchive', checked)}
                />
              </div>

              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-center gap-2 text-blue-800">
                  <AlertTriangle className="h-4 w-4" />
                  <span className="font-medium">GDPR Compliance</span>
                </div>
                <p className="text-sm text-blue-700 mt-1">
                  Ensure your data retention policies comply with local regulations. Users can request data deletion at any time.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}