'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { 
  Users, 
  AlertTriangle, 
  CheckCircle, 
  Clock,
  MapPin,
  Phone,
  Mail
} from 'lucide-react'

interface SOSRecord {
  id: string
  userId: string
  title?: string
  message?: string
  createdAt: string
  location: { lat: number; lng: number; accuracy?: number }
  status: 'queued' | 'sent' | 'acknowledged' | 'resolved'
  delivery: { emailSent: boolean; pushSent: boolean; smsSent: boolean }
  acks: Array<{ uid?: string; name?: string; timestamp: string }>
}

interface User {
  id: string
  name: string
  email: string
  phone?: string
  createdAt: string
  lastActiveAt: string
}

export default function AdminDashboard() {
  const [sosRecords, setSosRecords] = useState<SOSRecord[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Mock data - in production, this would fetch from Firestore
    const mockSOSRecords: SOSRecord[] = [
      {
        id: '1',
        userId: 'user1',
        title: 'Emergency Help Needed',
        message: 'I need immediate assistance',
        createdAt: '2024-01-15T10:30:00Z',
        location: { lat: 40.7128, lng: -74.0060, accuracy: 10 },
        status: 'acknowledged',
        delivery: { emailSent: true, pushSent: true, smsSent: false },
        acks: [
          { name: 'John Doe', timestamp: '2024-01-15T10:32:00Z' },
          { name: 'Jane Smith', timestamp: '2024-01-15T10:35:00Z' }
        ]
      },
      {
        id: '2',
        userId: 'user2',
        title: 'Help Request',
        message: 'Feeling unsafe',
        createdAt: '2024-01-15T09:15:00Z',
        location: { lat: 34.0522, lng: -118.2437, accuracy: 15 },
        status: 'resolved',
        delivery: { emailSent: true, pushSent: true, smsSent: false },
        acks: [
          { name: 'Mike Johnson', timestamp: '2024-01-15T09:20:00Z' }
        ]
      },
      {
        id: '3',
        userId: 'user3',
        title: 'Urgent SOS',
        message: 'Need help now',
        createdAt: '2024-01-15T11:45:00Z',
        location: { lat: 51.5074, lng: -0.1278, accuracy: 8 },
        status: 'sent',
        delivery: { emailSent: true, pushSent: true, smsSent: false },
        acks: []
      }
    ]

    const mockUsers: User[] = [
      {
        id: 'user1',
        name: 'Alice Johnson',
        email: 'alice@example.com',
        phone: '+1234567890',
        createdAt: '2024-01-01T00:00:00Z',
        lastActiveAt: '2024-01-15T10:30:00Z'
      },
      {
        id: 'user2',
        name: 'Bob Smith',
        email: 'bob@example.com',
        phone: '+1234567891',
        createdAt: '2024-01-02T00:00:00Z',
        lastActiveAt: '2024-01-15T09:15:00Z'
      },
      {
        id: 'user3',
        name: 'Carol Williams',
        email: 'carol@example.com',
        phone: '+1234567892',
        createdAt: '2024-01-03T00:00:00Z',
        lastActiveAt: '2024-01-15T11:45:00Z'
      }
    ]

    setSosRecords(mockSOSRecords)
    setUsers(mockUsers)
    setLoading(false)
  }, [])

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'resolved': return 'bg-green-100 text-green-800'
      case 'acknowledged': return 'bg-blue-100 text-blue-800'
      case 'sent': return 'bg-yellow-100 text-yellow-800'
      case 'queued': return 'bg-gray-100 text-gray-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const activeSOS = sosRecords.filter(record => record.status !== 'resolved')
  const totalUsers = users.length
  const todaySOS = sosRecords.filter(record => 
    new Date(record.createdAt).toDateString() === new Date().toDateString()
  ).length

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Overview of SafeCircle system status and activity</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalUsers}</div>
            <p className="text-xs text-muted-foreground">Registered users</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active SOS</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeSOS.length}</div>
            <p className="text-xs text-muted-foreground">Pending resolution</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's SOS</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{todaySOS}</div>
            <p className="text-xs text-muted-foreground">SOS events today</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Resolved</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {sosRecords.filter(r => r.status === 'resolved').length}
            </div>
            <p className="text-xs text-muted-foreground">Successfully resolved</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent SOS Events */}
      <Card>
        <CardHeader>
          <CardTitle>Recent SOS Events</CardTitle>
          <CardDescription>Latest emergency alerts requiring attention</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {activeSOS.slice(0, 5).map((record) => (
              <div key={record.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge className={getStatusColor(record.status)}>
                      {record.status}
                    </Badge>
                    <span className="text-sm text-gray-500">
                      {new Date(record.createdAt).toLocaleString()}
                    </span>
                  </div>
                  <h4 className="font-medium">{record.title || 'SOS Alert'}</h4>
                  <p className="text-sm text-gray-600">{record.message}</p>
                  <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      <span>{record.location.lat.toFixed(4)}, {record.location.lng.toFixed(4)}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Mail className="h-4 w-4" />
                      <span>{record.acks.length} acknowledgments</span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    View Details
                  </Button>
                  {record.status !== 'resolved' && (
                    <Button variant="default" size="sm">
                      Resolve
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}