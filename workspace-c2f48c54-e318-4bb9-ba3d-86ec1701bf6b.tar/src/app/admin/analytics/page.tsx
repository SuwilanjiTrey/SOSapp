'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Area,
  AreaChart
} from 'recharts'
import { 
  TrendingUp, 
  TrendingDown, 
  Users, 
  AlertTriangle, 
  Clock,
  CheckCircle,
  Activity,
  MapPin
} from 'lucide-react'

interface AnalyticsData {
  sosTrend: Array<{ date: string; count: number }>
  statusDistribution: Array<{ name: string; value: number; color: string }>
  deliveryStats: Array<{ method: string; sent: number; failed: number }>
  userActivity: Array<{ date: string; active: number; new: number }>
  locationData: Array<{ region: string; count: number }>
  responseTime: Array<{ hour: string; avgTime: number }>
}

export default function AdminAnalytics() {
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null)
  const [timeRange, setTimeRange] = useState<string>('7d')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Mock analytics data - in production, this would fetch from Firestore
    const mockData: AnalyticsData = {
      sosTrend: [
        { date: 'Jan 9', count: 12 },
        { date: 'Jan 10', count: 19 },
        { date: 'Jan 11', count: 8 },
        { date: 'Jan 12', count: 15 },
        { date: 'Jan 13', count: 22 },
        { date: 'Jan 14', count: 18 },
        { date: 'Jan 15', count: 25 }
      ],
      statusDistribution: [
        { name: 'Resolved', value: 45, color: '#10b981' },
        { name: 'Acknowledged', value: 25, color: '#3b82f6' },
        { name: 'Sent', value: 20, color: '#f59e0b' },
        { name: 'Queued', value: 10, color: '#6b7280' }
      ],
      deliveryStats: [
        { method: 'Email', sent: 95, failed: 5 },
        { method: 'Push', sent: 88, failed: 12 },
        { method: 'SMS', sent: 45, failed: 8 }
      ],
      userActivity: [
        { date: 'Jan 9', active: 120, new: 8 },
        { date: 'Jan 10', active: 135, new: 12 },
        { date: 'Jan 11', active: 118, new: 6 },
        { date: 'Jan 12', active: 142, new: 15 },
        { date: 'Jan 13', active: 155, new: 18 },
        { date: 'Jan 14', active: 148, new: 11 },
        { date: 'Jan 15', active: 162, new: 20 }
      ],
      locationData: [
        { region: 'North America', count: 45 },
        { region: 'Europe', count: 32 },
        { region: 'Asia', count: 28 },
        { region: 'South America', count: 15 },
        { region: 'Africa', count: 8 },
        { region: 'Oceania', count: 5 }
      ],
      responseTime: [
        { hour: '00:00', avgTime: 8.5 },
        { hour: '04:00', avgTime: 12.3 },
        { hour: '08:00', avgTime: 5.2 },
        { hour: '12:00', avgTime: 4.8 },
        { hour: '16:00', avgTime: 6.1 },
        { hour: '20:00', avgTime: 7.4 }
      ]
    }

    setAnalyticsData(mockData)
    setLoading(false)
  }, [timeRange])

  const renderStatCard = (title: string, value: string | number, change: number, icon: React.ReactNode) => {
    const isPositive = change >= 0
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">{title}</CardTitle>
          {icon}
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{value}</div>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            {isPositive ? (
              <TrendingUp className="h-3 w-3 text-green-500" />
            ) : (
              <TrendingDown className="h-3 w-3 text-red-500" />
            )}
            <span className={isPositive ? 'text-green-500' : 'text-red-500'}>
              {isPositive ? '+' : ''}{change}%
            </span>
            <span>from last period</span>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (loading || !analyticsData) {
    return <div className="flex items-center justify-center h-64">Loading analytics...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Analytics</h1>
          <p className="text-gray-600">System performance and usage metrics</p>
        </div>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="24h">Last 24 Hours</SelectItem>
            <SelectItem value="7d">Last 7 Days</SelectItem>
            <SelectItem value="30d">Last 30 Days</SelectItem>
            <SelectItem value="90d">Last 90 Days</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {renderStatCard(
          'Total SOS Events',
          '119',
          12,
          <AlertTriangle className="h-4 w-4 text-muted-foreground" />
        )}
        {renderStatCard(
          'Active Users',
          '1,247',
          8,
          <Users className="h-4 w-4 text-muted-foreground" />
        )}
        {renderStatCard(
          'Avg Response Time',
          '6.2s',
          -15,
          <Clock className="h-4 w-4 text-muted-foreground" />
        )}
        {renderStatCard(
          'Resolution Rate',
          '94%',
          3,
          <CheckCircle className="h-4 w-4 text-muted-foreground" />
        )}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* SOS Trend */}
        <Card>
          <CardHeader>
            <CardTitle>SOS Events Trend</CardTitle>
            <CardDescription>Daily SOS event count over time</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={analyticsData.sosTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Area 
                  type="monotone" 
                  dataKey="count" 
                  stroke="#ef4444" 
                  fill="#ef4444" 
                  fillOpacity={0.2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Status Distribution</CardTitle>
            <CardDescription>Breakdown of SOS event statuses</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={analyticsData.statusDistribution}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}%`}
                >
                  {analyticsData.statusDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* User Activity */}
        <Card>
          <CardHeader>
            <CardTitle>User Activity</CardTitle>
            <CardDescription>Daily active and new users</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={analyticsData.userActivity}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="active" 
                  stroke="#3b82f6" 
                  strokeWidth={2}
                  name="Active Users"
                />
                <Line 
                  type="monotone" 
                  dataKey="new" 
                  stroke="#10b981" 
                  strokeWidth={2}
                  name="New Users"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Delivery Success Rate */}
        <Card>
          <CardHeader>
            <CardTitle>Delivery Success Rate</CardTitle>
            <CardDescription>Notification delivery by method</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={analyticsData.deliveryStats}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="method" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="sent" fill="#10b981" name="Sent" />
                <Bar dataKey="failed" fill="#ef4444" name="Failed" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Geographic Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Geographic Distribution</CardTitle>
            <CardDescription>SOS events by region</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={analyticsData.locationData} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="region" type="category" width={80} />
                <Tooltip />
                <Bar dataKey="count" fill="#8b5cf6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Response Time by Hour */}
        <Card>
          <CardHeader>
            <CardTitle>Average Response Time</CardTitle>
            <CardDescription>Response time by hour of day</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={analyticsData.responseTime}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="hour" />
                <YAxis />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="avgTime" 
                  stroke="#f59e0b" 
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Summary Insights */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Key Insights
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="p-4 border rounded-lg">
              <h4 className="font-medium text-green-700 mb-2">Peak Performance</h4>
              <p className="text-sm text-gray-600">
                Best response times during business hours (8AM-4PM) with an average of 5.2 seconds.
              </p>
            </div>
            <div className="p-4 border rounded-lg">
              <h4 className="font-medium text-blue-700 mb-2">High Activity</h4>
              <p className="text-sm text-gray-600">
                SOS events increased by 12% this week, with North America showing the highest activity.
              </p>
            </div>
            <div className="p-4 border rounded-lg">
              <h4 className="font-medium text-purple-700 mb-2">Delivery Success</h4>
              <p className="text-sm text-gray-600">
                Email delivery shows the highest success rate at 95%, while SMS maintains 45% delivery.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}